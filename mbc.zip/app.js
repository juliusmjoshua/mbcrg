class PaymentReceipt {
    constructor(
        providerName, providerEmail, providerPhone,
        payerName, payerEmail, payerPhone, paymentDate, 
        serviceDescription, amountCharged, totalPaid, balance, 
        paymentStatus, department, level, matricNumber, projectTopic,
        paymentType, selectedProvider
    ) {
        this.providerName = providerName;
        this.providerEmail = providerEmail;
        this.providerPhone = providerPhone;
        this.payerName = payerName;
        this.payerEmail = payerEmail;
        this.payerPhone = payerPhone;
        this.paymentDate = paymentDate;
        this.serviceDescription = serviceDescription;
        this.amountCharged = parseFloat(amountCharged); 
        this.totalPaid = parseFloat(totalPaid); 
        this.balance = parseFloat(balance); 
        this.paymentStatus = paymentStatus;
        this.department = department;
        this.level = level;
        this.matricNumber = matricNumber;
        this.projectTopic = projectTopic;
        this.paymentType = paymentType;
        this.selectedProvider = selectedProvider;
        this.retrievalNumber = this.generateRetrievalNumber();
        this.discount = 0;
        this.discountAmount = 0;
    }

    generateRetrievalNumber() {
        return 'RN-' + Math.random().toString(36).substr(2, 9).toUpperCase();
    }

    generateQRCode() {
        const qrcode = window.qrcode(0, 'M');
        const qrData = JSON.stringify({
            retrievalNumber: this.retrievalNumber,
            payerName: this.payerName,
            paymentDate: this.paymentDate,
            totalPaid: this.totalPaid
        });
        qrcode.addData(qrData);
        qrcode.make();
        return qrcode.createImgTag(3);
    }

    generateReceiptHTML(copyType = '') {
        const currentDateTime = new Date().toLocaleString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: true
        });

        return `
            <div class="receipt">
                <div class="receipt-copy-type">${copyType}</div>
                <div class="receipt-qr-top">
                    ${this.generateQRCode()}
                </div>
                <div class="receipt-watermark">MANCHA BUSINESS CENTER</div>
                <div class="receipt-header">
                    <img src="logo.png" alt="Mancha Business Center Logo" class="receipt-logo">
                    <h1>MANCHA BUSINESS CENTER</h1>
                    <h2>PLATEAU STATE POLYTECHNIC BARKIN LADI</h2>
                </div>
                <div class="receipt-content">
                    <h2>Payment Receipt</h2>
                    <p><strong>Retrieval Number:</strong> ${this.retrievalNumber}</p>
                    <p><strong>Date & Time:</strong> ${currentDateTime}</p>
                    
                    <h3>Service Provider Details</h3>
                    <p><strong>Provider:</strong> ${this.selectedProvider}</p>
                    <p><strong>Business Name:</strong> ${this.providerName}</p>
                    <p><strong>Email:</strong> ${this.providerEmail}</p>
                    <p><strong>Phone:</strong> ${this.providerPhone}</p>
                    
                    <h3>Payer Details</h3>
                    <p><strong>Name:</strong> ${this.payerName}</p>
                    <p><strong>Email:</strong> ${this.payerEmail}</p>
                    <p><strong>Phone:</strong> ${this.payerPhone}</p>
                    
                    <h3>Payment Information</h3>
                    <p><strong>Payment Date:</strong> ${this.paymentDate}</p>
                    <p><strong>Payment Type:</strong> ${this.paymentType}</p>
                    <p><strong>Service Description:</strong> ${this.serviceDescription}</p>
                    <div class="receipt-financial-details">
                        <p><strong>Amount Charged:</strong> ₦${this.amountCharged.toFixed(2)}</p>
                        ${this.discount > 0 ? `
                            <p><strong>Discount (${this.discount}%):</strong> ₦${this.discountAmount.toFixed(2)}</p>
                        ` : ''}
                        <p><strong>Total Paid:</strong> ₦${this.totalPaid.toFixed(2)}</p>
                        <p><strong>Balance:</strong> ₦${this.balance.toFixed(2)}</p>
                    </div>
                    
                    <h3>Student Information</h3>
                    <p><strong>Department:</strong> ${this.department}</p>
                    <p><strong>Level:</strong> ${this.level}</p>
                    <p><strong>Matriculation Number:</strong> ${this.matricNumber}</p>
                    ${this.projectTopic ? `<p><strong>Project Topic:</strong> ${this.projectTopic}</p>` : ''}
                </div>
                <div class="receipt-footer">
                    <p>Thanks for your business! Call Again!</p>
                </div>
            </div>
        `;
    }

    save() {
        const savedReceipts = JSON.parse(localStorage.getItem('paymentReceipts') || '[]');
        savedReceipts.push(this);
        localStorage.setItem('paymentReceipts', JSON.stringify(savedReceipts));
    }

    static loadSavedReceipts() {
        const receipts = JSON.parse(localStorage.getItem('paymentReceipts') || '[]');
        
        return receipts.map(receipt => {
            const restoredReceipt = new PaymentReceipt(
                receipt.providerName, 
                receipt.providerEmail, 
                receipt.providerPhone,
                receipt.payerName, 
                receipt.payerEmail, 
                receipt.payerPhone, 
                receipt.paymentDate, 
                receipt.serviceDescription, 
                receipt.amountCharged, 
                receipt.totalPaid, 
                receipt.balance, 
                receipt.paymentStatus, 
                receipt.department, 
                receipt.level, 
                receipt.matricNumber, 
                receipt.projectTopic,
                receipt.paymentType, 
                receipt.selectedProvider
            );
            
            restoredReceipt.retrievalNumber = receipt.retrievalNumber;
            restoredReceipt.discount = parseFloat(receipt.discount || 0);
            restoredReceipt.discountAmount = parseFloat(receipt.discountAmount || 0);
            
            return restoredReceipt;
        });
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('paymentReceiptForm');
    const receiptDisplay = document.getElementById('receiptDisplay');
    const savedReceiptsList = document.getElementById('savedReceiptsList');
    const downloadButtons = document.querySelector('.download-buttons');

    function displaySavedReceipts() {
        const savedReceipts = PaymentReceipt.loadSavedReceipts();
        savedReceiptsList.innerHTML = savedReceipts.map(receipt => 
            `<li data-retrieval-number="${receipt.retrievalNumber}">
                ${receipt.retrievalNumber} - ${receipt.payerName} (₦${receipt.totalPaid.toFixed(2)})
            </li>`
        ).join('');
    }

    displaySavedReceipts();

    document.getElementById('downloadPDF').addEventListener('click', async () => {
        const receipt = receiptDisplay.querySelector('.receipt');
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        
        const canvas = await html2canvas(receipt);
        const imgData = canvas.toDataURL('image/png');
        doc.addImage(imgData, 'PNG', 10, 10, 190, 0);
        doc.save('receipt.pdf');
    });

    document.getElementById('downloadPNG').addEventListener('click', async () => {
        const receipt = receiptDisplay.querySelector('.receipt');
        const canvas = await html2canvas(receipt);
        const link = document.createElement('a');
        link.download = 'receipt.png';
        link.href = canvas.toDataURL();
        link.click();
    });

    document.getElementById('downloadJPG').addEventListener('click', async () => {
        const receipt = receiptDisplay.querySelector('.receipt');
        const canvas = await html2canvas(receipt);
        const link = document.createElement('a');
        link.download = 'receipt.jpg';
        link.href = canvas.toDataURL('image/jpeg');
        link.click();
    });

    const printButton = document.createElement('button');
    printButton.id = 'printReceipt';
    printButton.textContent = 'Print Receipt';
    downloadButtons.appendChild(printButton);

    printButton.addEventListener('click', () => {
        const receipt = receiptDisplay.querySelector('.receipt');
        if (receipt) {
            const printWindow = window.open('', '', 'width=600,height=600');
            printWindow.document.open();
            printWindow.document.write(`
                <html>
                    <head>
                        <title>Print Receipt</title>
                        <link rel="stylesheet" href="styles.css">
                        <style>
                            body { display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
                            .receipt { max-width: 500px; width: 100%; }
                        </style>
                    </head>
                    <body>
                        ${receipt.outerHTML}
                        <script>
                            window.onload = function() {
                                window.print();
                                window.onafterprint = function() {
                                    window.close();
                                }
                            }
                        </script>
                    </body>
                </html>
            `);
            printWindow.document.close();
        }
    });

    const providerSelect = document.getElementById('providerSelect');
    const otherProviderName = document.getElementById('otherProviderName');
    const providerEmail = document.getElementById('providerEmail');
    const providerPhone = document.getElementById('providerPhone');

    const providerDetails = {
        'Markus Pam Mancha': {
            email: 'pmancha1626@gmail.com',
            phone: '07031941002'
        },
        'Mwadkon Julius Joshua': {
            email: 'juliusmjoshua@gmail.com',
            phone: '07088459052'
        },
        'Pam Helen': {
            email: 'hpmanch@gmail.com',
            phone: '07039641115'
        },
        'Pereh Choji': {
            email: 'chojipererattemmanuel@gmail.com',
            phone: '07065003661'
        }
    };

    providerSelect.addEventListener('change', (e) => {
        const selectedProvider = e.target.value;
        if (selectedProvider === 'Others') {
            otherProviderName.style.display = 'block';
            otherProviderName.required = true;
            providerEmail.value = '';
            providerEmail.readOnly = false;
            providerPhone.value = '';
            providerPhone.readOnly = false;
        } else {
            otherProviderName.style.display = 'none';
            otherProviderName.required = false;
            
            if (providerDetails[selectedProvider]) {
                providerEmail.value = providerDetails[selectedProvider].email;
                providerPhone.value = providerDetails[selectedProvider].phone;
                providerEmail.readOnly = true;
                providerPhone.readOnly = true;
            } else {
                providerEmail.value = '';
                providerEmail.readOnly = false;
                providerPhone.value = '';
                providerPhone.readOnly = false;
            }
        }
    });

    const amountChargedSelect = document.getElementById('amountCharged');
    const discountSelect = document.getElementById('discount');
    const discountAmountInput = document.getElementById('discountAmount');
    const totalPaidInput = document.getElementById('totalPaid');
    const balanceInput = document.getElementById('balance');

    const paymentTypeSelect = document.getElementById('paymentType');
    const otherPaymentTypeInput = document.createElement('input');
    otherPaymentTypeInput.type = 'text';
    otherPaymentTypeInput.id = 'otherPaymentType';
    otherPaymentTypeInput.placeholder = 'Enter payment type';
    otherPaymentTypeInput.style.display = 'none';
    otherPaymentTypeInput.style.marginTop = '10px';

    // Insert the new input after the payment type select
    paymentTypeSelect.parentNode.insertBefore(otherPaymentTypeInput, paymentTypeSelect.nextSibling);

    paymentTypeSelect.addEventListener('change', (e) => {
        const selectedPaymentType = e.target.value;
        if (selectedPaymentType === 'Others') {
            otherPaymentTypeInput.style.display = 'block';
            otherPaymentTypeInput.required = true;
        } else {
            otherPaymentTypeInput.style.display = 'none';
            otherPaymentTypeInput.required = false;
        }
    });

    const serviceDescriptionSelect = document.getElementById('serviceDescriptionSelect');
    const otherServiceDescription = document.getElementById('otherServiceDescription');
    const projectTopicInput = document.getElementById('projectTopic');
    const projectTopicContainer = document.getElementById('projectTopicContainer');

    // Create a container for the project topic input if it doesn't exist
    if (!projectTopicContainer) {
        const projectTopicGroup = document.querySelector('input[id="projectTopic"]').closest('.form-group');
        projectTopicGroup.id = 'projectTopicContainer';
    }

    serviceDescriptionSelect.addEventListener('change', (e) => {
        const selectedDescription = e.target.value;
        
        // Handle "Others" service description
        if (selectedDescription === 'Others') {
            otherServiceDescription.style.display = 'block';
            otherServiceDescription.required = true;
        } else {
            otherServiceDescription.style.display = 'none';
            otherServiceDescription.required = false;
        }

        // Handle project topic visibility
        const projectTopicContainer = document.getElementById('projectTopicContainer');
        if (selectedDescription === 'Assignment') {
            projectTopicContainer.style.display = 'none';
            projectTopicInput.value = ''; // Clear the input
            projectTopicInput.required = false;
        } else {
            projectTopicContainer.style.display = 'block';
            projectTopicInput.required = true;
        }
    });

    function calculateFinancials() {
        const amount = parseFloat(amountChargedSelect.value) || 0;
        const discountPercentage = parseFloat(discountSelect.value) || 0;
        const discountAmount = (amount * discountPercentage) / 100;
        const totalAfterDiscount = amount - discountAmount;
        
        discountAmountInput.value = discountAmount.toFixed(2);
        
        // Update Total Paid calculation to consider total after discount
        totalPaidInput.addEventListener('input', calculateBalance);
    }

    function calculateBalance() {
        const totalAfterDiscount = parseFloat(amountChargedSelect.value) - 
            ((parseFloat(amountChargedSelect.value) * parseFloat(discountSelect.value)) / 100);
        const totalPaid = parseFloat(totalPaidInput.value) || 0;
        const balance = totalAfterDiscount - totalPaid;
        
        balanceInput.value = balance.toFixed(2);
    }

    amountChargedSelect.addEventListener('change', calculateFinancials);
    discountSelect.addEventListener('change', calculateFinancials);
    totalPaidInput.addEventListener('input', calculateBalance);

    form.addEventListener('submit', (e) => {
        e.preventDefault();

        document.getElementById('loader').style.display = 'flex';
        NProgress.start();

        setTimeout(() => {
            const selectedProvider = providerSelect.value === 'Others' 
                ? otherProviderName.value 
                : providerSelect.value;
            const providerName = document.getElementById('providerName').value;
            const providerEmailValue = document.getElementById('providerEmail').value;
            const providerPhoneValue = document.getElementById('providerPhone').value;
            const payerName = document.getElementById('payerName').value;
            const payerEmail = document.getElementById('payerEmail').value;
            const payerPhone = document.getElementById('payerPhone').value;
            const paymentDate = document.getElementById('paymentDate').value;
            const serviceDescription = serviceDescriptionSelect.value === 'Others' 
                ? otherServiceDescription.value 
                : serviceDescriptionSelect.value;
            const amountCharged = parseFloat(document.getElementById('amountCharged').value);
            const discountPercentage = parseFloat(document.getElementById('discount').value);
            const discountAmount = (amountCharged * discountPercentage) / 100;
            const totalAfterDiscount = amountCharged - discountAmount;
            const totalPaid = parseFloat(document.getElementById('totalPaid').value);
            const balance = totalAfterDiscount - totalPaid;
            const paymentStatus = document.getElementById('paymentStatus').value;
            const department = document.getElementById('department').value;
            const level = document.getElementById('level').value;
            const matricNumber = document.getElementById('matricNumber').value;
            const projectTopic = document.getElementById('projectTopic').value;
            const paymentType = paymentTypeSelect.value === 'Others' 
                ? otherPaymentTypeInput.value 
                : paymentTypeSelect.value;

            const receipt = new PaymentReceipt(
                providerName, providerEmailValue, providerPhoneValue,
                payerName, payerEmail, payerPhone, paymentDate, 
                serviceDescription, amountCharged, totalPaid, balance, 
                paymentStatus, department, level, matricNumber, projectTopic,
                paymentType, selectedProvider
            );
            
            receipt.discount = discountPercentage;
            receipt.discountAmount = discountAmount;
            
            // Generate two copies of the receipt
            const customerCopy = receipt.generateReceiptHTML('Customer Copy');
            const duplicateCopy = receipt.generateReceiptHTML('Duplicate Copy');
            
            // Display both copies
            receiptDisplay.innerHTML = `
                <div class="receipt-copies">
                    <div class="customer-copy">${customerCopy}</div>
                    <div class="duplicate-copy">${duplicateCopy}</div>
                </div>
            `;
            
            downloadButtons.style.display = 'block';
            
            receipt.save();
            displaySavedReceipts();
            form.reset();
            
            document.getElementById('providerName').value = 'MANCHA BUSINESS CENTER';

            document.getElementById('loader').style.display = 'none';
            NProgress.done();

            // Success notification
            const successNotification = document.createElement('div');
            successNotification.className = 'success-notification';
            successNotification.textContent = 'Receipt Generated Successfully!';
            document.body.appendChild(successNotification);

            // Remove notification after 3 seconds
            setTimeout(() => {
                document.body.removeChild(successNotification);
            }, 3000);
        }, 2000);
    });

    const receiptViewModal = document.getElementById('receiptViewModal');
    const editReceiptForm = document.getElementById('editReceiptForm');
    const updateReceiptBtn = document.getElementById('updateReceiptBtn');
    const closeModalBtn = document.querySelector('.close-modal');

    closeModalBtn.addEventListener('click', () => {
        receiptViewModal.style.display = 'none';
    });

    savedReceiptsList.addEventListener('click', (e) => {
        if (e.target.tagName === 'LI') {
            const retrievalNumber = e.target.dataset.retrievalNumber;
            const savedReceipts = PaymentReceipt.loadSavedReceipts();
            const receipt = savedReceipts.find(r => r.retrievalNumber === retrievalNumber);
            
            if (receipt) {
                editReceiptForm.innerHTML = `
                    <input type="hidden" id="editRetrievalNumber" value="${receipt.retrievalNumber}">
                    <div class="form-group">
                        <label>Retrieval Number</label>
                        <input type="text" value="${receipt.retrievalNumber}" readonly>
                    </div>
                    <div class="form-group">
                        <label>Service Provider</label>
                        <input type="text" name="selectedProvider" value="${receipt.selectedProvider}">
                    </div>
                    <div class="form-group">
                        <label>Payer Name</label>
                        <input type="text" name="payerName" value="${receipt.payerName}">
                    </div>
                    <div class="form-group">
                        <label>Payer Email</label>
                        <input type="email" name="payerEmail" value="${receipt.payerEmail}">
                    </div>
                    <div class="form-group">
                        <label>Payer Phone</label>
                        <input type="tel" name="payerPhone" value="${receipt.payerPhone}">
                    </div>
                    <div class="form-group">
                        <label>Service Description</label>
                        <textarea name="serviceDescription">${receipt.serviceDescription}</textarea>
                    </div>
                    <div class="form-group">
                        <label>Total Paid</label>
                        <input type="number" name="totalPaid" value="${receipt.totalPaid}" step="0.01">
                    </div>
                    <div class="form-group">
                        <label>Payment Status</label>
                        <select name="paymentStatus">
                            <option value="Pending" ${receipt.paymentStatus === 'Pending' ? 'selected' : ''}>Pending</option>
                            <option value="Paid" ${receipt.paymentStatus === 'Paid' ? 'selected' : ''}>Paid</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <button type="button" id="reprintReceiptBtn" class="reprint-btn">Reprint Receipt</button>
                    </div>
                `;
                
                receiptViewModal.style.display = 'block';

                // Add reprint functionality
                const reprintReceiptBtn = document.getElementById('reprintReceiptBtn');
                reprintReceiptBtn.addEventListener('click', () => {
                    const fullReceipt = new PaymentReceipt(
                        receipt.providerName, 
                        receipt.providerEmail, 
                        receipt.providerPhone,
                        receipt.payerName, 
                        receipt.payerEmail, 
                        receipt.payerPhone, 
                        receipt.paymentDate, 
                        receipt.serviceDescription, 
                        receipt.amountCharged, 
                        receipt.totalPaid, 
                        receipt.balance, 
                        receipt.paymentStatus, 
                        receipt.department, 
                        receipt.level, 
                        receipt.matricNumber, 
                        receipt.projectTopic,
                        receipt.paymentType, 
                        receipt.selectedProvider
                    );
                    
                    // Restore additional receipt properties
                    fullReceipt.retrievalNumber = receipt.retrievalNumber;
                    fullReceipt.discount = receipt.discount;
                    fullReceipt.discountAmount = receipt.discountAmount;
                    
                    // Display the receipt
                    receiptDisplay.innerHTML = fullReceipt.generateReceiptHTML();
                    downloadButtons.style.display = 'block';
                    
                    // Close the modal
                    receiptViewModal.style.display = 'none';

                    // Add reprint notification
                    const reprintNotification = document.createElement('div');
                    reprintNotification.className = 'success-notification';
                    reprintNotification.textContent = 'Receipt Reprinted Successfully!';
                    document.body.appendChild(reprintNotification);

                    // Remove notification after 3 seconds
                    setTimeout(() => {
                        document.body.removeChild(reprintNotification);
                    }, 3000);
                });
            }
        }
    });

    const deleteReceiptBtn = document.createElement('button');
    deleteReceiptBtn.id = 'deleteReceiptBtn';
    deleteReceiptBtn.textContent = 'Delete Receipt';
    deleteReceiptBtn.style.backgroundColor = '#f44336';
    deleteReceiptBtn.style.marginTop = '10px';
    receiptViewModal.querySelector('.modal-buttons').appendChild(deleteReceiptBtn);

    deleteReceiptBtn.addEventListener('click', () => {
        const retrievalNumber = document.getElementById('editRetrievalNumber').value;
        const savedReceipts = PaymentReceipt.loadSavedReceipts();
        
        const updatedReceipts = savedReceipts.filter(receipt => 
            receipt.retrievalNumber !== retrievalNumber
        );

        localStorage.setItem('paymentReceipts', JSON.stringify(updatedReceipts));
        
        displaySavedReceipts();
        
        receiptViewModal.style.display = 'none';
    });

    updateReceiptBtn.addEventListener('click', () => {
        const savedReceipts = PaymentReceipt.loadSavedReceipts();
        const retrievalNumber = document.getElementById('editRetrievalNumber').value;
        
        const updatedReceipts = savedReceipts.map(receipt => {
            if (receipt.retrievalNumber === retrievalNumber) {
                const formData = new FormData(editReceiptForm);
                for (let [key, value] of formData.entries()) {
                    if (receipt.hasOwnProperty(key)) {
                        receipt[key] = value;
                    }
                }
            }
            return receipt;
        });

        localStorage.setItem('paymentReceipts', JSON.stringify(updatedReceipts));
        
        displaySavedReceipts();
        
        receiptViewModal.style.display = 'none';

        // Add update success notification
        const successNotification = document.createElement('div');
        successNotification.className = 'success-notification';
        successNotification.textContent = 'Receipt Updated Successfully!';
        document.body.appendChild(successNotification);

        // Remove notification after 3 seconds
        setTimeout(() => {
            document.body.removeChild(successNotification);
        }, 3000);
    });

    const lookupReferenceInput = document.getElementById('lookupReferenceNumber');
    const lookupReferenceBtn = document.getElementById('lookupReferenceBtn');
    const lookupResult = document.getElementById('lookupResult');

    lookupReferenceBtn.addEventListener('click', () => {
        const referenceNumber = lookupReferenceInput.value.trim();
        const savedReceipts = PaymentReceipt.loadSavedReceipts();
        const foundReceipt = savedReceipts.find(r => r.retrievalNumber === referenceNumber);

        if (foundReceipt) {
            lookupResult.innerHTML = `
                <div class="lookup-receipt-details">
                    <h3>Receipt Details</h3>
                    <div class="receipt-info-grid">
                        <div class="info-section">
                            <h4>Retrieval Information</h4>
                            <p><strong>Retrieval Number:</strong> ${foundReceipt.retrievalNumber}</p>
                            <p><strong>Payment Date:</strong> ${foundReceipt.paymentDate}</p>
                            <p><strong>Payment Status:</strong> ${foundReceipt.paymentStatus}</p>
                        </div>
                        
                        <div class="info-section">
                            <h4>Service Provider Details</h4>
                            <p><strong>Provider:</strong> ${foundReceipt.selectedProvider}</p>
                            <p><strong>Business Name:</strong> ${foundReceipt.providerName}</p>
                            <p><strong>Email:</strong> ${foundReceipt.providerEmail}</p>
                            <p><strong>Phone:</strong> ${foundReceipt.providerPhone}</p>
                        </div>
                        
                        <div class="info-section">
                            <h4>Payer Details</h4>
                            <p><strong>Name:</strong> ${foundReceipt.payerName}</p>
                            <p><strong>Email:</strong> ${foundReceipt.payerEmail}</p>
                            <p><strong>Phone:</strong> ${foundReceipt.payerPhone}</p>
                        </div>
                        
                        <div class="info-section">
                            <h4>Payment Information</h4>
                            <p><strong>Payment Type:</strong> ${foundReceipt.paymentType}</p>
                            <p><strong>Service Description:</strong> ${foundReceipt.serviceDescription}</p>
                            <p><strong>Amount Charged:</strong> ₦${foundReceipt.amountCharged.toFixed(2)}</p>
                            <p><strong>Total Paid:</strong> ₦${foundReceipt.totalPaid.toFixed(2)}</p>
                            <p><strong>Balance:</strong> ₦${foundReceipt.balance.toFixed(2)}</p>
                        </div>
                        
                        <div class="info-section">
                            <h4>Student Information</h4>
                            <p><strong>Department:</strong> ${foundReceipt.department}</p>
                            <p><strong>Level:</strong> ${foundReceipt.level}</p>
                            <p><strong>Matriculation Number:</strong> ${foundReceipt.matricNumber}</p>
                            ${foundReceipt.projectTopic ? `<p><strong>Project Topic:</strong> ${foundReceipt.projectTopic}</p>` : ''}
                        </div>
                    </div>
                    <div class="lookup-actions">
                        <button id="viewFullReceipt">View Full Receipt</button>
                    </div>
                </div>
            `;

            document.getElementById('viewFullReceipt').addEventListener('click', () => {
                const fullReceipt = new PaymentReceipt(
                    foundReceipt.providerName, 
                    foundReceipt.providerEmail, 
                    foundReceipt.providerPhone,
                    foundReceipt.payerName, 
                    foundReceipt.payerEmail, 
                    foundReceipt.payerPhone, 
                    foundReceipt.paymentDate, 
                    foundReceipt.serviceDescription, 
                    foundReceipt.amountCharged, 
                    foundReceipt.totalPaid, 
                    foundReceipt.balance, 
                    foundReceipt.paymentStatus, 
                    foundReceipt.department, 
                    foundReceipt.level, 
                    foundReceipt.matricNumber, 
                    foundReceipt.projectTopic,
                    foundReceipt.paymentType, 
                    foundReceipt.selectedProvider
                );
                
                receiptDisplay.innerHTML = fullReceipt.generateReceiptHTML();
                downloadButtons.style.display = 'block';
            });
        } else {
            lookupResult.innerHTML = '<p>No receipt found with this reference number.</p>';
        }
    });
});